package cs.hku.comp7506proj

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import cs.hku.comp7506proj.auth.LoginScreen
import cs.hku.comp7506proj.auth.ProfileScreen
import cs.hku.comp7506proj.auth.SignUpScreen
import cs.hku.comp7506proj.data.CommentData
import cs.hku.comp7506proj.data.PostData
import cs.hku.comp7506proj.main.*
import cs.hku.comp7506proj.ui.theme.Comp7506ProjTheme
import dagger.hilt.android.AndroidEntryPoint
import org.w3c.dom.Comment

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Comp7506ProjTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    ProjApp()
                }
            }
        }
    }
}

sealed class DestinationScreen(val route: String ){
    object Signup: DestinationScreen(route = "Signup")
    object Login: DestinationScreen(route = "login")
    object Feed: DestinationScreen(route = "feed")
    object Search: DestinationScreen(route = "Search")
    object MyPost: DestinationScreen(route = "MyPost")
    object Profile: DestinationScreen(route = "Profile")
    object NewPost: DestinationScreen(route = "NewPost/{imageUri}"){
        fun createRoute(uri: String) = "NewPost/$uri"
    }
    object SinglePost: DestinationScreen("singlepost")
    object CommentScreen: DestinationScreen("comments/{postId}"){
        fun createRoute(postId: String) = "comments/$postId"
    }
}

@Composable
fun ProjApp(){
    val vm = hiltViewModel<ProjViewModel>()
    val navController = rememberNavController()

    NotificationMessage(vm = vm)

    NavHost(navController = navController, startDestination = DestinationScreen.Signup.route){
        composable(DestinationScreen.Signup.route){
            SignUpScreen(navController = navController, vm = vm)
        }

        composable(DestinationScreen.Login.route){
            LoginScreen(navController = navController, vm = vm)
        }

        composable(DestinationScreen.Feed.route){
            FeedScreen(navController = navController, vm = vm)
        }

        composable(DestinationScreen.Search.route){
            SearchScreen(navController = navController, vm = vm)
        }

        composable(DestinationScreen.MyPost.route){
            MyPostScreen(navController = navController, vm = vm)
        }

        composable(DestinationScreen.Profile.route){
            ProfileScreen(navController = navController, vm = vm)
        }

        composable(DestinationScreen.NewPost.route) { navBackStackEntry ->
            val imageUri = navBackStackEntry.arguments?.getString("imageUri")
            imageUri?.let {
                NewPostScreen(navController = navController, vm = vm, encodedUri = it)
            }
        }

        composable(DestinationScreen.SinglePost.route){
            val postData = navController
                .previousBackStackEntry
                ?.arguments
                ?.getParcelable<PostData>("post")
            postData?.let {
                SinglePostScreen(
                    navController = navController,
                    vm = vm,
                    post = postData
                )
            }
        }

        composable(DestinationScreen.CommentScreen.route){ navBackStackEntry->
            val postId = navBackStackEntry.arguments?.getString("postId")
            postId?.let { CommentScreen(navController = navController, vm = vm, postId = it) }
        }

    }

}


@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    Comp7506ProjTheme {
        ProjApp()
    }
}