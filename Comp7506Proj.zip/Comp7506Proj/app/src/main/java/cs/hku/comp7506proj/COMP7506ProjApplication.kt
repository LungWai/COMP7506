package cs.hku.comp7506proj

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class COMP7506ProjApplication : Application () {
}