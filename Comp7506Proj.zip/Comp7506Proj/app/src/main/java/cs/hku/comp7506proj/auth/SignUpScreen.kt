package cs.hku.comp7506proj.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Button
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import cs.hku.comp7506proj.DestinationScreen
import cs.hku.comp7506proj.ProjViewModel
import cs.hku.comp7506proj.R
import cs.hku.comp7506proj.main.CommonProgressSpinner
import cs.hku.comp7506proj.main.checkSignin
import cs.hku.comp7506proj.main.navigateTo


@Composable
fun SignUpScreen(navController: NavController, vm: ProjViewModel){

    checkSignin(vm = vm, navController = navController)
    val focus = LocalFocusManager.current

    Box(modifier = Modifier.fillMaxSize()){
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .verticalScroll(
                    rememberScrollState()
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            val usernameState = remember{ mutableStateOf(TextFieldValue())}
            val emailState = remember{ mutableStateOf(TextFieldValue())}
            val pwState = remember{ mutableStateOf(TextFieldValue())}

            Image(
                painter = painterResource(id = R.drawable.pets_logo),
                contentDescription = null,
                modifier = Modifier
                    .width(250.dp)
                    .padding(top = 16.dp)
                    .padding(8.dp)
            )
            Text(
                text = "Sign Up",
                modifier = Modifier.padding(8.dp),
                fontSize = 24.sp,
                fontFamily = FontFamily.SansSerif
            )
            
            OutlinedTextField(
                value = usernameState.value,
                onValueChange = {usernameState.value = it},
                modifier = Modifier.padding(8.dp),
                label = {Text(text = "Username")}
            )

            OutlinedTextField(
                value = emailState.value,
                onValueChange = {emailState.value = it},
                modifier = Modifier.padding(8.dp),
                label = {Text(text = "Email")}
            )

            OutlinedTextField(
                value = pwState.value,
                onValueChange = {pwState.value = it},
                modifier = Modifier.padding(8.dp),
                label = {Text(text = "Password")},
                visualTransformation = PasswordVisualTransformation()
            )
            Button(onClick = {
                focus.clearFocus(force = true)
                vm.onSignup(
                    usernameState.value.text,
                    emailState.value.text,
                    pwState.value.text
                )
            },
                modifier = Modifier.padding(8.dp)) {
                Text(text = "sign up")
            }
            Text(
                text = "Already a user? Go to Login",
                color = Color.Blue,
                modifier = Modifier
                    .padding(8.dp)
                    .clickable {
                        navigateTo(navController, DestinationScreen.Login)
                    }
            )
        }

        val isLoading = vm.inProgress.value
        if (isLoading){
            CommonProgressSpinner()
        }

    }
}